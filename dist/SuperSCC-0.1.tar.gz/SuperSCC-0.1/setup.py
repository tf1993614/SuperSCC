from setuptools import setup, find_packages

setup(
    name='SuperSCC',
    version='0.1',
    packages=find_packages(),
    author="Feng Tang",
    install_requires = ["dcor==0.6", 
                        "scanpy==1.10.1", 
                        "pandas==2.2.2", 
                        "numpy==1.26.4", 
                        "scipy==1.13.0", 
                        "scikit-learn==1.2.2", 
                        "igraph==0.11.4", 
                        "leidenalg==0.10.2", 
                        "plotly==5.22.0", 
                        "rpy2==3.5.17", 
                        "langchain==0.3.18",
                        "langchain-community==0.3.17"]
)

