library(tidyverse)
library(snow)


#' create a function to calculate jaccard_score
#' @export
jaccard_score = function(x , y) {
  library(tidyverse)
  intersection_size = length(dplyr::intersect(x, y))
  union_size = length(dplyr::union(x, y))
  return(intersection_size/union_size)
}


#' create a function to calculate the overlap between groups
#' @export
find_overlap_singlet = function(data, full_search = FALSE) {
  size = dim(data)[2]
  pb = txtProgressBar(min = 0, max = size, style = 3)
  map_dfr(
    seq(size),
    function(num) {
      setTxtProgressBar(pb, num)
      base = data[, num, drop = TRUE]
      base_name = colnames(data[, num, drop = FALSE])
      if (full_search) {
        compare = data
      }
      else {
        compare = data[, ! colnames(data) %in% colnames(data)[seq(num)], drop = FALSE]
      }
      map_dfr(
        colnames(compare),
        ~ data.frame(number = length(dplyr::intersect(base, compare[, colnames(compare) == .x, drop = TRUE])),
                     base_name = base_name,
                     compare_name = .x)
      )
    }
  )
}


#' A function to calculate pairwise intersection size among all groups
#' @export
find_overlap_base = function(data, index, full_search = FALSE) {
  library(tidyverse)
  # get the base elements and its group name   
  base = data[[index]] # index is the colunm index to assign the base group
  base_name = colnames(data[, index, drop = FALSE])
  
  if (isFALSE(full_search)) {
    # remove base group column from the data
    remove_groups = seq(index)
    compare = data[, ! colnames(data) %in% colnames(data)[remove_groups], drop = FALSE]
  }
  else {
    compare = data
  }
  
  # calculate the intersection between base group and 
  # each remaining column in the data
  map_dfr(
    colnames(compare),
    ~ data.frame(
      number =  length(dplyr::intersect(base, compare[, colnames(compare) == .x, drop = TRUE])), # jaccard_score(base, compare[, colnames(compare) == .x, drop = TRUE]),
      base_name = base_name,
      compare_name = .x
    )
  )
}

#' A function to calculate pairwise intersection size between a specified group and other groups
#' @export
find_overlap_founder = function(data, index) {
  library(tidyverse)
  
  founder = data[["founder"]] # get the founder group
  base_name = "founder"
  
  compare = data[, colnames(data) != "founder"] # remove the founder group from the data
  compare_name = colnames(compare[, index, drop = FALSE]) 
  compare = compare[, index, drop = TRUE] # get the compare group (index is the column index assign the compare column)
  
  data.frame(
    number = length(dplyr::intersect(founder, compare)), # jaccard_score(founder, compare), 
    base_name = base_name,
    compare_name = compare_name
  )
}

#' A function to run find_ovarlap_base parallely
#' @export
do_intersection_base = function(data, parallel_num = 8) {
  
  if (is.null(parallel_num)) {
    intersect_data = find_overlap_singlet(data)
  }
  else {
    cl = snow::makeCluster(get("parallel_num"))
    snow::clusterEvalQ(cl, {library(tidyverse)})
    snow::clusterExport(cl, "find_overlap_base")
    snow::clusterExport(cl, "jaccard_score")
    snow::clusterExport(cl, "data")
    
    intersect_data = clusterApply(cl, 1:dim(data)[2], function(index) find_overlap_base(data, index))
    intersect_data = do.call(rbind, intersect_data)
    stopCluster(cl)
  }
  
  return(intersect_data)
}

#' A function to run find_ovarlap_founder parallely
#' @export
do_intersection_founder = function(data, parallel_num = 8) {
  
  cl = snow::makeCluster(get("parallel_num"))
  snow::clusterEvalQ(cl, {library(tidyverse)})
  snow::clusterExport(cl, "find_overlap_founder")
  snow::clusterExport(cl, "jaccard_score")
  snow::clusterExport(cl, "data")
  
  intersect_data = clusterApply(cl, 1:(dim(data)[2]-1), function(index) find_overlap_founder(data, index))
  intersect_data = do.call(rbind, intersect_data)
  stopCluster(cl)
  
  return(intersect_data)
}

#' A underlying function to get gene module
#' @export
core_get_gene_module = function(data,
                                intersect_size = 10, 
                                intersect_group_size = 5,
                                parallel_num = 8,
                                init_signal = TRUE){
  library(tidyverse)
  pre_data_for_intersection = dplyr::mutate(data, across(everything(), ~ str_remove(.x, "/.+")))
  
  if (init_signal) {
    intersect_data = do_intersection_base(data = pre_data_for_intersection, parallel_num = parallel_num)
  }
  else {
    intersect_data = do_intersection_founder(data = pre_data_for_intersection, parallel_num = parallel_num)
  }
  
  intersect_data = subset(intersect_data, number > intersect_size)
  intersect_data = arrange(intersect_data, desc(number))
  
  if (dim(intersect_data)[1] >= intersect_group_size) {
    
    max_overlap_members = c(intersect_data[1, 2], intersect_data[1, 3])
    
    
    overlap_count = sort(table(c(pre_data_for_intersection[, max_overlap_members[1], drop = TRUE], pre_data_for_intersection[, max_overlap_members[2], drop= TRUE])), decreasing = TRUE)
    
    intersection_genes = dplyr::intersect(pre_data_for_intersection[, max_overlap_members[1], drop = TRUE], pre_data_for_intersection[, max_overlap_members[2], drop = TRUE])
    union_genes = dplyr::union(pre_data_for_intersection[, max_overlap_members[1], drop = TRUE], pre_data_for_intersection[, max_overlap_members[2], drop = TRUE])
    diff_genes = dplyr::setdiff(union_genes, intersection_genes)
    
    genes_ranking_pool_1 = data.frame(genes = str_remove(data[, max_overlap_members[1], drop = TRUE], "/.+"),
                                      scores = str_remove(data[, max_overlap_members[1], drop = TRUE], "[^/]+/"))
    
    
    intersection_genes_ranking_1 = subset(genes_ranking_pool_1, genes %in% intersection_genes)
    
    genes_ranking_pool_2 = data.frame(genes = str_remove(data[, max_overlap_members[2], drop = TRUE], "/.+"),
                                      scores = str_remove(data[, max_overlap_members[2], drop = TRUE], "[^/]+/"))
    
    intersection_genes_ranking_2 = subset(genes_ranking_pool_2, genes %in% intersection_genes)
    
    
    intersection_genes_ranking_final = bind_rows(intersection_genes_ranking_1, intersection_genes_ranking_2)
    intersection_genes_ranking_final = group_by(intersection_genes_ranking_final, genes)
    intersection_genes_ranking_final = ungroup(arrange(intersection_genes_ranking_final, desc(scores), .by_group = TRUE))
    intersection_genes_ranking_final = distinct(intersection_genes_ranking_final, genes, .keep_all = TRUE)
    
    if (length(intersection_genes) != 50) {
      robust_names = intersection_genes 
      
      diff_genes_ranking_1 = subset(genes_ranking_pool_1, genes %in% diff_genes)
      diff_genes_ranking_2 = subset(genes_ranking_pool_2, genes %in% diff_genes)
      
      final_ranking = arrange(bind_rows(intersection_genes_ranking_final, diff_genes_ranking_1, diff_genes_ranking_2), desc(scores))
      
      final_ranking_border = subset(final_ranking, genes %in% diff_genes)
      
      final_ranking_border = head(final_ranking_border, (50 - length(robust_names))) 
      
      final_ranking_robust = subset(final_ranking, genes %in% robust_names)
      
      final_top50_ranking = bind_rows(final_ranking_border, final_ranking_robust)
      
      founder = paste0(final_top50_ranking$genes, "/", final_top50_ranking$scores)
    } else {
      final_top50_ranking = head(intersection_genes_ranking_final, 50) 
      founder = paste0(final_top50_ranking$genes, "/", final_top50_ranking$scores)
    }
    
    update_data = data[, ! colnames(data) %in% max_overlap_members]
    update_data["founder"] = founder
    core_get_gene_module(data = update_data, parallel_num = parallel_num, init_signal = FALSE)
  } 
  
  else {
    return(data)
  }
}

#' get_gene_module
#' 
#' A function to get gene module
#'
#' @param data A data frame with each column containing the gene sets.
#' @param intersect_size A int value to determine the cutoff of intersection size.
#' @param intersect_size A int value to determine the cutoff of intersection group size. 
#' @param parallel_num A int value to determine the cutoff of parallel number.
#' @export
get_gene_module = function(data, 
                           intersect_size = 10,
                           intersect_group_size = 5,
                           parallel_num = 8) {
  library(tidyverse)
  meta_program_list = vector(mode = "list", length = dim(data)[2])
  meta_program_members = vector(mode = "list", length = dim(data)[2])
  meta_program_data = vector(mode = "list", length = dim(data)[2])
  loc = 1
  
  signal = TRUE # the signal to control while loop
  
  while (signal) {
    meta_program_data[[loc]] = data
    
    output = core_get_gene_module(data = data, 
                                  intersect_size = intersect_size,
                                  intersect_group_size = intersect_group_size,
                                  parallel_num = parallel_num)
    update_data = output[, colnames(output) != "founder"] # remove founder column from the output
    
    if (dim(update_data)[2] == dim(data)[2]) {
      if (all(colnames(update_data) == colnames(data))) {
        signal = FALSE # when update_data is same as data, indicating there is no satisfied intersection and should terminate the while loop 
      }
    }
    else {
      message(paste0("Finding the gene module ", loc))
      meta_program_list[[loc]] = output[["founder"]] # get the meta gene program/gene module
      meta_program_members[[loc]] = dplyr::setdiff(colnames(data), colnames(update_data)) # get the members contributing to the gene module
      data = update_data # update_data removing the members contributing to current gene module used for finding the next gene module
      loc = loc + 1
    }
  }
  
  # remove NULL elements in the following list
  meta_program_list = meta_program_list[map_lgl(meta_program_list, ~ ! is.null(.x))]
  meta_program_members = meta_program_members[map_lgl(meta_program_members, ~ ! is.null(.x))]
  meta_program_data = meta_program_data[map_lgl(meta_program_data, ~ ! is.null(.x))]
  
  return(list(gene_module = meta_program_list, module_members = meta_program_members, remained_gene_sets = meta_program_data))
}
